DEFAULT_HORIZON = 23

from .microgrid import Microgrid
